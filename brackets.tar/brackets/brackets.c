#include <unistd.h>

void	ft_ok(void)
{
	write(1, "OK\n", 3);
}

void	ft_er(void)
{
	write(1, "Error\n", 6);
}

int		ft_isin(char c, char *str)
{
	if (!str)
		return (0);
	while (*str && *str != c)
		str++;
	return (*str == c);
}

char	ft_lastopen(char *str, int len)
{
	int	prev;

	prev = 0;
	while (len >= 0)
	{
		if (ft_isin(str[len], "([{"))
			prev--;
		if (ft_isin(str[len], ")]}"))
			prev++;
		if (prev == 0)
			return (str[len]);
		len--;
	}
	return ('\0');
}

int		ft_brack(char *str)
{
	int	p[3];
	int	i;

	p[0] = 0;
	p[1] = 0;
	p[2] = 0;
	i = 0;
	while (str[i])
	{
		if (str[i] == '(')
			p[0]++;
		if (str[i] == '[')
			p[1]++;
		if (str[i] == '{')
			p[2]++;
		if (str[i] == ')')
		{
			if (ft_lastopen(str, i) != '(')
				return (0);
			p[0]--;
		}
		if (str[i] == ']')
		{
			if (ft_lastopen(str, i) != '[')
				return (0);
			p[1]--;
		}
		if (str[i] == '}')
		{
			if (ft_lastopen(str, i) != '{')
				return (0);
			p[2]--;
		}
		if (p[0] < 0 || p[1] < 0 || p[2] < 0)
			return (0);
		i++;
	}
	return (p[0] == 0 && p[1] == 0 && p[2] == 0);
}

int	main(int ac, char **av)
{
	int	i;

	i = 1;
	if (ac == 1)
		write(1, "\n", 1);
	while (i < ac)
	{
		if (ft_brack(av[i]))
			ft_ok();
		else
			ft_er();
		i++;
	}
	return (0);
}
